using Ledger.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
namespace Ledger.Controllers
{
    [Route("api/[controller]")]
    public class TransactionController : Controller
    {
        Repositories.ITransactionRepository _transactionRepository;

        public TransactionController(Repositories.ITransactionRepository _transactionrepo)
        {
            this._transactionRepository = _transactionrepo
        }

        [HttpGet]
        public ICollection<Transaction> All()
        {
            return this._transactionRepository.GetAllTransactions();
        }

        [HttpGet("/api/transaction/getbyuserid/{id}")]
        public List<Transaction> GetByUserID(Guid? id)
        {
           
            return this._transactionRepository.
                        GetAllTransactions()
                        .Where(t => t.UserID == id)
                        .ToList();
        }
    }
}
