using Catalog.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;

namespace Catalog.Controllers
{
    [Route("api/[controller]")]
    public class ProductController : Controller
    {

        Repositories.IProductRepository _repository;
        public ProductController(Repositories.IProductRepository repository)
        {
            this._repository = repository;
        }
        [HttpGet]
        public ICollection<Product>  All()
        {
            return this._repository.GetAllProducts();

        }
    }
}
