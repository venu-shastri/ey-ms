using Authentication.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Authentication.Controllers
{
    [Route("api/[controller]")]
    public class UserController : Controller
    {
        Repositories.IUserRepository _userRepo;

        public UserController(Repositories.IUserRepository userRepo)
        {
            this._userRepo = userRepo;
        }

        [HttpGet]
        public ICollection<User> All()
        {
            return this._userRepo.GetAllUsers();
        }
        [HttpGet("/api/user/getbyid/{id}")]
        public User GetByID(Guid? id)
        {
           
            return this._userRepo.GetAllUsers().
                FirstOrDefault(u => u.UserId == id);
        }
    }
}
