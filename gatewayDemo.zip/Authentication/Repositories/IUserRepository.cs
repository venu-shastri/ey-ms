﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Authentication.Repositories
{
    public interface IUserRepository
    {
        Guid AddNewUser(Models.User);
        ICollection<Models.User> GetAllUsers();
    }
}
