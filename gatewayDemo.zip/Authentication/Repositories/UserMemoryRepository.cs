﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Authentication.Models;

namespace Authentication.Repositories
{
    public class UserMemoryRepository : IUserRepository
    {
        List<User> _userList = null;

        public UserMemoryRepository() {
            _userList = new List<User>()
            {
                new User() { FirstName = "Allan", LastName = "Chua", UserId = Guid.Parse("539bf338-e5de-4fc4-ac65-4a91324d8111") },
                new User() { FirstName = "Burr", LastName = "Sutter", UserId = Guid.Parse("6b2c4788-e1d5-4ef4-8edf-e7d57e31bf4f") },
                new User() { FirstName = "Josh", LastName = "Long", UserId = Guid.Parse("3a4149fa-32e9-4d4a-a051-5c49b7ed2fca") }
            };
        }
    public Guid AddNewUser(User modelState )
        {
            throw new NotImplementedException();
        }

        public ICollection<User> GetAllUsers()
        {
            throw new NotImplementedException();
        }
    }
}
