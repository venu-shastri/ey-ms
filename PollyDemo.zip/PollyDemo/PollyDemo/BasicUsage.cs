﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace PollyDemo
{
    public class BasicUsage
    {
        private readonly IHttpClientFactory _clientFactory;
        public BasicUsage(IHttpClientFactory clientFactory)
        {
            this._clientFactory = clientFactory;
        }
        public async Task Get()
        {
            var request = new HttpRequestMessage(HttpMethod.Get,
                "url");
            request.Headers.Add("key", "value");
            request.Headers.Add("key", "value");

            var client = _clientFactory.CreateClient();

            var response = await client.SendAsync(request);

            if (response.IsSuccessStatusCode)
            {
                //Success
            }
            else
            {
                //failure
            }
        }
    }
}
