﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;

namespace PollyDemo
{
    public class Startup
    {
        // This method gets called by the runtime. Use this method to add services to the container.
        // For more information on how to configure your application, visit https://go.microsoft.com/fwlink/?LinkID=398940
        public void ConfigureServices(IServiceCollection services)
        {
            //Basic Usgae
            services.AddHttpClient();
            //Name Client
            services.AddHttpClient("Name", c =>
            {
                c.BaseAddress = new Uri("URL");
                c.DefaultRequestHeaders.Add("key", "value");
                c.DefaultRequestHeaders.Add("Key", "value");
            });
            //Typed Client
            services.AddHttpClient<TestServiceProxy>(). SetHandlerLifetime(TimeSpan.FromMinutes(5)); 

            services.AddTransient<HttpRequestMiddleware>();

            services.AddHttpClient("externalservice", c =>
            {
                // Assume this is an "external" service which requires an API KEY
                c.BaseAddress = new Uri("https://localhost:5000/");
            })
            .AddHttpMessageHandler<HttpRequestMiddleware>();

            //Generated Client
            services.AddHttpClient("hello", c =>
            {
                c.BaseAddress = new Uri("http://localhost:5000");
            })
        .AddTypedClient(c => Refit.RestService.For<IHelloClient>(c));

            services.AddMvc();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.Run(async (context) =>
            {
                await context.Response.WriteAsync("Hello World!");
            });
        }
    }
}
