﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace PollyDemo
{
    public class TypedClient
    {
        private readonly TestServiceProxy _proxy;
        public TypedClient(TestServiceProxy proxy)
        {
            this._proxy = proxy;
        }

        public async Task Get()
        {
            try
            {
                var result = await this._proxy.InvokeServiceMethod();
            }
            catch (HttpRequestException)
            {
                
            }
        }
    }
}
