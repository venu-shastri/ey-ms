﻿using Microsoft.AspNetCore.Mvc;
using Refit;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PollyDemo
{
    public interface IHelloClient
    {
        [Get("/helloworld")]
        Task<Reply> GetMessageAsync();
    }

    public class Reply
    {
        public string Message { get; set; }
    }
    public class GeneratedClient
    {
        private readonly IHelloClient _client;

        public GeneratedClient(IHelloClient client)
        {
            _client = client;
        }

        
        public async Task<Reply> Invoke()
        {
            return await _client.GetMessageAsync();
        }
    }
}
