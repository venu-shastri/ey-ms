﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace PollyDemo
{
    public class TestServiceProxy
    {
        private readonly HttpClient _client;
        public TestServiceProxy(HttpClient client)
        {
            client.BaseAddress = new Uri("URL");
            
            client.DefaultRequestHeaders.Add("Key","Value");

            client.DefaultRequestHeaders.Add("Key", "Value");

            this._client = client;
        }

        public async Task<string> InvokeServiceMethod()
        {
            var response = await this._client.GetAsync(
                "URL Segment");

            response.EnsureSuccessStatusCode();

            var result = await response.Content.ReadAsStringAsync();
                

            return result;
        }
    }
}
