﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace PollyDemo
{
    public class NamedClient
    {
        private readonly IHttpClientFactory _clientFactory;

       


        public NamedClient(IHttpClientFactory clientFactory)
        {
            _clientFactory = clientFactory;
        }

        public async Task Get()
        {
            var request = new HttpRequestMessage(HttpMethod.Get,
                "URL segments");

            var client = _clientFactory.CreateClient("Name");

            var response = await client.SendAsync(request);

            if (response.IsSuccessStatusCode)
            {
                string responseContent = await response.Content.ReadAsStringAsync();
                    
            }
            else
            {
               
            }
        }
    }
}
