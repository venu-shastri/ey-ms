﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Caching;
using Microsoft.Extensions.Caching.Distributed;

namespace CacheSample
{
    public class SqlCacheMiddleware
    {
        RequestDelegate _next;
        IDistributedCache _cache;
        IMessageService _messageService;
        
        public SqlCacheMiddleware(RequestDelegate next,IDistributedCache cache,IMessageService messageService)
        {
            this._cache = cache;
            this._next = next;
            this._messageService = messageService;
        }

        public Task Invoke(HttpContext httpContext)
        {
            string cacheKey = "testKey";
            string message;

            // try to get the cached item; null if not found
            // greeting = _cache.Get(cacheKey) as string;

            message=_cache.GetString(cacheKey);
            // alternately, TryGet returns true if the cache entry was found
            if (string.IsNullOrEmpty(message))
            {
                // fetch the value from the source
                message = _messageService.GetMessage();

                // store in the cache
                _cache.SetString(cacheKey, message);
                    

            }


            return httpContext.Response.WriteAsync(message);
        }
    }
}
