﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Caching.Memory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CacheSample
{
    public class TestMiddleware
    {
        RequestDelegate _next;
        IMemoryCache _cache;
        IMessageService _messageService;
        public TestMiddleware(RequestDelegate next,IMemoryCache cache,IMessageService messageService)
        {
            this._next = next;
            this._cache = cache;
            this._messageService = messageService;

        }
        public Task Invoke(HttpContext httpContext)
        {
            string cacheKey = "testKey";
            string message;

            // try to get the cached item; null if not found
            // greeting = _cache.Get(cacheKey) as string;

            // alternately, TryGet returns true if the cache entry was found
            if (!_cache.TryGetValue(cacheKey, out message))
            {
                // fetch the value from the source
                message = _messageService.GetMessage();

                // store in the cache
                _cache.Set(cacheKey, message,
                    new MemoryCacheEntryOptions()
                    .SetAbsoluteExpiration(TimeSpan.FromMinutes(1)));
                
            }
            

            return httpContext.Response.WriteAsync(message);
        }


    }
}
