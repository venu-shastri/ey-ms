﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Caching.SqlServer;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Caching.Redis;

namespace CacheSample
{
    public class Startup
    {
        // This method gets called by the runtime. Use this method to add services to the container.
        // For more information on how to configure your application, visit https://go.microsoft.com/fwlink/?LinkID=398940
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddMemoryCache();
            //services.AddDistributedSqlServerCache(options => {
            //    options.ConnectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\venu\recipe-application.mdf;Integrated Security=True;Connect Timeout=30";
            //    options.SchemaName = "dbo";
            //    options.TableName = "TestCache";
            //});
            
           
            services.AddSingleton(typeof(IMessageService), typeof(MessageService));
            services.AddDistributedRedisCache(s => {
                s.Configuration = "localhost:6379";
                s.InstanceName = "master";
            });
        }


        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();

                // app.UseMiddleware<TestMiddleware>();
                //   app.UseMiddleware<SqlCacheMiddleware>();
                app.UseMiddleware<RedisCacheMiddleware>();
                app.Run(async (context) =>
                {
                    await context.Response.WriteAsync("Hello World!");
                });
            }

        }
    }
}
