﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CacheSample
{
    public class MessageService : IMessageService
    {
        public string GetMessage()
        {
            return DateTime.Now.ToLongTimeString();
        }
    }
}
