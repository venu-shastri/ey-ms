﻿namespace CacheSample
{
    public interface IMessageService
    {
        string GetMessage();
    }
}