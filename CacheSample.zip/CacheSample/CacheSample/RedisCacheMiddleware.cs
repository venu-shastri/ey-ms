﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Caching.Distributed;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CacheSample
{
    public class RedisCacheMiddleware
    {
        RequestDelegate _next;
        IDistributedCache _cache;
        IMessageService _messageService;

        public RedisCacheMiddleware(RequestDelegate next, IDistributedCache cache, IMessageService messageService)
        {
            this._cache = cache;
            this._next = next;
            this._messageService = messageService;
        }

        public async Task Invoke(HttpContext httpContext)
        {
            string cacheKey = "testKey";
            string message;

            // try to get the cached item; null if not found
            // greeting = _cache.Get(cacheKey) as string;

            message = await _cache.GetStringAsync(cacheKey);
            // alternately, TryGet returns true if the cache entry was found
            if (string.IsNullOrEmpty(message))
            {
                // fetch the value from the source
                message = _messageService.GetMessage();

                // store in the cache
                _cache.SetString(cacheKey, message);


            }


           await httpContext.Response.WriteAsync(message);
        }
    }
}
