﻿namespace ConsulDemoApi.Client.Models
{
    public class ValueWrapper
    {
        public string Value { get; set; }
    }
}
