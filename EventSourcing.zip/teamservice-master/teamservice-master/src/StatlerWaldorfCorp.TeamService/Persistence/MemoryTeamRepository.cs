using System;
using System.Collections.Generic;
using System.Linq;
using StatlerWaldorfCorp.TeamService;
using StatlerWaldorfCorp.TeamService.Models;

namespace StatlerWaldorfCorp.TeamService.Persistence
{
	public class MemoryTeamRepository :  ITeamRepository {
		protected static ICollection<Team> teams;

        static MemoryTeamRepository()
        {
            teams = new List<Team>();
            var team1 = new Team { ID = "TEAM01", Name = "ABC" };
            team1.Members.Add(new Member { ID = "ABCMEM1", FirstName = "PQR", LastName = "XYZ" });
            team1.Members.Add(new Member { ID = "ABCMEM2", FirstName = "ABC", LastName = "DEF" });

            
            teams.Add(team1);
        }
		public MemoryTeamRepository() {
			
            
		}

		public MemoryTeamRepository(ICollection<Team> teams) {
            MemoryTeamRepository.teams = teams;
		}

		public IEnumerable<Team> List() {
			return teams; 
		}

		public Team Get(string id) {
			return teams.FirstOrDefault(t => t.ID == id);			
		}

		public Team Update(Team t) 
		{
			Team team = this.Delete(t.ID);
	
			if(team != null) {
				team = this.Add(t);
			}

			return team;
		}

		public Team Add(Team team) 
		{
			teams.Add(team);
			return team;
		}

		public Team Delete(string id) {	
			var q = teams.Where(t => t.ID == id);
			Team team = null;

			if (q.Count() > 0) {				
				team = q.First();
				teams.Remove(team);
			}							

			return team; 			
		}
	}
}