[![wercker status](https://app.wercker.com/status/98cdd1f2575eae0ae490e5032d95a2df/s/master "wercker status")](https://app.wercker.com/project/byKey/98cdd1f2575eae0ae490e5032d95a2df)

# Team Service
The first microservice sample from the **Building Microservices with ASP.NET Core** book.