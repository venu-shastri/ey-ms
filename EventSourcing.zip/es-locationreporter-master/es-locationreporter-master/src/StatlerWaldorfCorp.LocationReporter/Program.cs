﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Configuration;
using System.IO;

namespace StatlerWaldorfCorp.LocationReporter
{
    public class Program
    {
        public static void Main(string[] args)
        {


            var host = new WebHostBuilder()
                .UseKestrel()
                .UseStartup<Startup>()
                .UseContentRoot(Directory.GetCurrentDirectory())
                .UseUrls("http://localhost:5050")
				.Build();

	    	host.Run();
        }
    }
}
