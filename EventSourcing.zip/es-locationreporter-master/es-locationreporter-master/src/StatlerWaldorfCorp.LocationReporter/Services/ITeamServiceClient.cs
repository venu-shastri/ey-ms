using System;

namespace StatlerWaldorfCorp.LocationReporter.Services
{
    public interface ITeamServiceClient
    {
        string GetTeamForMember(string memberId);
    }
}