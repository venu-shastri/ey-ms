namespace StatlerWaldorfCorp.LocationReporter.Models
{
    public class TeamServiceOptions 
    {
        public string Url = "http://localhost:5000";
    }
}