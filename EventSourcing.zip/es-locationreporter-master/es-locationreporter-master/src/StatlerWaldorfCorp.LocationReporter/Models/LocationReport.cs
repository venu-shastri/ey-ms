using System;

namespace StatlerWaldorfCorp.LocationReporter.Models
{
    public class LocationReport
    {
        public string ReportID { get; set; }
        public String Origin { get; set; }
        public double Latitude { get; set; }
        public double Longitude { get; set; }
        public string MemberID { get; set; }
    }
}
