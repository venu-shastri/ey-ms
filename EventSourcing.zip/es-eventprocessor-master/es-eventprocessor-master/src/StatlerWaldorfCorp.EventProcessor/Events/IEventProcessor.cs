namespace StatlerWaldorfCorp.EventProcessor.Events
{
    public interface IEventProcessor
    {
        void Start();
        void Stop();   
    }
}