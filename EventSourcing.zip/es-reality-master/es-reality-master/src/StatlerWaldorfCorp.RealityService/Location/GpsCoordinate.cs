namespace StatlerWaldorfCorp.RealityService.Location
{
    public class GpsCoordinate
    {
        public double Latitude { get; set; }
        public double Longitude { get; set; }
        
    }
}